import React from "react";
import { createRoot } from "https://unpkg.com/react-dom@18/umd/react-dom.development.js";
import App from "./App.jsx";

const mount = document.getElementById("root");
const root = ReactDOM.createRoot(mount);
root.render(React.createElement(App));
