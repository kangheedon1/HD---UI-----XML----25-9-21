import React, { useState } from "react";

const Pill = ({ active, onClick, children }) => (
  <button
    onClick={onClick}
    className={`pill ${active ? "active" : ""}`}
  >
    {children}
  </button>
);

export default function App() {
  const [keyword, setKeyword] = useState("");
  const [title, setTitle] = useState("");
  const [position, setPosition] = useState("3");
  const [mode, setMode] = useState("video");
  const [minTime, setMinTime] = useState("60");
  const [maxTime, setMaxTime] = useState("180");
  const [proxy, setProxy] = useState("");
  const [logs, setLogs] = useState([]);

  const submit = (e) => {
    e.preventDefault();
    const line = `Task submitted | keyword="${keyword}", title="${title}", pos=${position}, mode=${mode}, time=${minTime}~${maxTime}, proxy="${proxy}"`;
    setLogs((prev) => [line, ...prev]);
    setKeyword(""); setTitle(""); setPosition("3");
    setMode("video"); setMinTime("60"); setMaxTime("180"); setProxy("");
  };

  return (
    <div className="app">
      <div className="card">
        <h1>YouTube Automation Tool</h1>
        <form onSubmit={submit}>
          <label>Keyword
            <input value={keyword} onChange={(e)=>setKeyword(e.target.value)} placeholder="예: lo-fi beats" required />
          </label>
          <label>Title (exact)
            <input value={title} onChange={(e)=>setTitle(e.target.value)} />
          </label>
          <label>Position (1=Top1 → N)
            <input type="number" value={position} min="1" onChange={(e)=>setPosition(e.target.value)} />
          </label>

          <div className="seg">
            <span>Mode</span>
            <div className="seg-buttons">
              <Pill active={mode==="live"} onClick={()=>setMode("live")}>Live</Pill>
              <Pill active={mode==="shorts"} onClick={()=>setMode("shorts")}>Shorts</Pill>
              <Pill active={mode==="video"} onClick={()=>setMode("video")}>Video</Pill>
            </div>
          </div>

          <div className="range">
            <span>Watch Time Range (sec)</span>
            <div className="range-grid">
              <input type="number" value={minTime} min="0" onChange={(e)=>setMinTime(e.target.value)} />
              <span className="to">to</span>
              <input type="number" value={maxTime} min="0" onChange={(e)=>setMaxTime(e.target.value)} />
            </div>
          </div>

          <label>Proxy (optional)
            <input value={proxy} onChange={(e)=>setProxy(e.target.value)} placeholder="http://user:pass@host:port" />
          </label>

          <button className="primary" type="submit">Submit Task</button>
        </form>

        <section className="logs">
          <h2>Task Logs</h2>
          <ul>
            {logs.map((l,i)=>(<li key={i}>{l}</li>))}
          </ul>
        </section>
      </div>
    </div>
  );
}
