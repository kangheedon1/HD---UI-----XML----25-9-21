#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HDGRACE BAS XML Generator - Fixed Version
BAS 29.2.0 Compatible with JSON/HTML Support
"""

import os
import sys
import json
import time
import logging
import random
import base64
import re
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field, asdict
import xml.etree.ElementTree as ET
from xml.dom import minidom

# 로깅 설정
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('hdgrace_bas_generator.log', encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# ====================== 설정 ======================
class Config:
    """전체 설정 관리"""
    OUTPUT_DIR = r"C:\Users\office2\Pictures\Desktop\3065"
    TOTAL_UI_ELEMENTS = 3065
    ACTIONS_PER_UI_MIN = 20
    ACTIONS_PER_UI_MAX = 40
    TOTAL_FEATURES = 3065

    # 기능 카테고리
    FEATURE_CATEGORIES = {
        "유튜브_자동화": 400,
        "프록시_관리": 350,
        "보안_회피": 300,
        "UI_인터페이스": 250,
        "시스템_모니터링": 200,
        "고급_최적화": 195,
        "기타_조합": 1370
    }

    # 필수 26개 블록
    REQUIRED_BLOCKS = [
        "Dat", "Updater", "DependencyLoader", "CompatibilityLayer",
        "Dash", "Script", "Resource", "Module", "Navigator", "Security",
        "Network", "Storage", "Scheduler", "UIComponents", "Macro",
        "Action", "Function", "LuxuryUI", "Theme", "Logging",
        "Metadata", "CpuMonitor", "ThreadMonitor", "MemoryGuard",
        "LogError", "RetryAction"
    ]

# ====================== 데이터 클래스 ======================
@dataclass
class UIElement:
    """UI 요소 정의"""
    id: str
    type: str  # button, input, toggle
    name: str
    visible: bool = True
    data_visible: bool = True
    aria_visible: bool = True
    enabled: bool = True
    emoji: str = ""
    category: str = ""

    def to_xml_element(self) -> ET.Element:
        """XML Element로 변환"""
        elem = ET.Element("UIElement")
        elem.set("id", self.id)
        elem.set("type", self.type)
        elem.set("name", self.name)
        elem.set("visible", "true")  # 강제 true
        elem.set("data-visible", "true")
        elem.set("aria-visible", "true")
        elem.set("enabled", str(self.enabled).lower())
        if self.emoji:
            elem.set("emoji", self.emoji)
        if self.category:
            elem.set("category", self.category)
        return elem

@dataclass
class Action:
    """액션 정의"""
    id: str
    name: str
    type: str  # Click, Type, Navigate, Wait, etc.
    target: str = ""
    value: str = ""
    timeout: int = 30
    retry: int = 3

    def to_xml_element(self) -> ET.Element:
        """XML Element로 변환"""
        elem = ET.Element("Action")
        elem.set("id", self.id)
        elem.set("name", self.name)
        elem.set("type", self.type)
        if self.target:
            elem.set("target", self.target)
        if self.value:
            elem.set("value", self.value)
        elem.set("timeout", str(self.timeout))
        elem.set("retry", str(self.retry))
        return elem

@dataclass
class Macro:
    """매크로 정의"""
    id: str
    name: str
    actions: List[str] = field(default_factory=list)
    visible: bool = True
    enabled: bool = True

    def to_xml_element(self) -> ET.Element:
        """XML Element로 변환"""
        elem = ET.Element("Macro")
        elem.set("id", self.id)
        elem.set("name", self.name)
        elem.set("visible", str(self.visible).lower())
        elem.set("enabled", str(self.enabled).lower())

        # 액션 리스트 추가
        actions_elem = ET.SubElement(elem, "Actions")
        for action_id in self.actions:
            action_ref = ET.SubElement(actions_elem, "ActionRef")
            action_ref.set("id", action_id)

        return elem

# ====================== 생성기 클래스 ======================
class BASXMLGenerator:
    """BAS XML 생성기 - 수정된 버전"""

    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.ui_elements: List[UIElement] = []
        self.actions: List[Action] = []
        self.macros: List[Macro] = []
        self.ensure_output_dir()

    def ensure_output_dir(self):
        """출력 디렉토리 생성"""
        Path(Config.OUTPUT_DIR).mkdir(parents=True, exist_ok=True)

    def safe_cdata_wrap(self, content: str) -> str:
        """CDATA 래핑 - ]]> 이스케이핑 포함"""
        if not content:
            return ""
        # ]]> 이스케이핑 처리
        escaped_content = str(content).replace(']]>', ']]]]><![CDATA[>')
        return f"<![CDATA[{escaped_content}]]>"

    def encode_logo_base64(self, logo_path: Optional[str] = None) -> str:
        """로고를 Base64로 인코딩"""
        # 기본 로고 데이터 (작은 투명 PNG)
        default_logo = (
            "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNkYPhfDwAChwGA60e6kgAAAABJRU5ErkJggg=="
        )

        if not logo_path or not os.path.exists(logo_path):
            return default_logo

        try:
            with open(logo_path, 'rb') as f:
                logo_data = f.read()
                return base64.b64encode(logo_data).decode('utf-8')
        except Exception as e:
            self.logger.warning(f"로고 인코딩 실패: {e}")
            return default_logo

    def generate_ui_elements(self) -> List[UIElement]:
        """UI 요소 생성"""
        self.logger.info(f"UI 요소 생성 시작: {Config.TOTAL_UI_ELEMENTS}개")

        emojis = ["✅", "❌", "⚠️", "🔒", "🚀", "💡", "📊", "🎯", "🔄", "⚡"]
        ui_types = ["button", "input", "toggle", "select", "checkbox"]

        for i in range(Config.TOTAL_UI_ELEMENTS):
            # 카테고리 결정
            category = self._get_category_for_index(i)

            ui_element = UIElement(
                id=f"ui_hdgrace_{i:04d}",
                type=ui_types[i % len(ui_types)],
                name=f"HDGRACE_{category}_{i:04d}",
                visible=True,
                data_visible=True,
                aria_visible=True,
                enabled=True,
                emoji=emojis[i % len(emojis)],
                category=category
            )
            self.ui_elements.append(ui_element)

        self.logger.info(f"UI 요소 생성 완료: {len(self.ui_elements)}개")
        return self.ui_elements

    def _get_category_for_index(self, index: int) -> str:
        """인덱스에 대한 카테고리 반환"""
        cumulative = 0
        for category, count in Config.FEATURE_CATEGORIES.items():
            cumulative += count
            if index < cumulative:
                return category
        return "기타_조합"

    def generate_actions(self) -> List[Action]:
        """액션 생성"""
        self.logger.info("액션 생성 시작")

        action_types = ["Click", "Type", "Navigate", "Wait", "Scroll",
                       "Hover", "Check", "Select", "Drag", "Drop"]

        action_id = 0
        for ui_element in self.ui_elements:
            # UI당 랜덤 개수의 액션 생성
            num_actions = random.randint(Config.ACTIONS_PER_UI_MIN,
                                        Config.ACTIONS_PER_UI_MAX)

            for j in range(num_actions):
                action = Action(
                    id=f"action_{action_id:06d}",
                    name=f"Action_{ui_element.category}_{action_id}",
                    type=action_types[action_id % len(action_types)],
                    target=ui_element.id,
                    value=f"value_{action_id}",
                    timeout=random.randint(10, 60),
                    retry=random.randint(1, 5)
                )
                self.actions.append(action)
                action_id += 1

        self.logger.info(f"액션 생성 완료: {len(self.actions)}개")
        return self.actions

    def generate_macros(self) -> List[Macro]:
        """매크로 생성"""
        self.logger.info("매크로 생성 시작")

        for i, ui_element in enumerate(self.ui_elements):
            # UI별 액션 그룹화
            ui_actions = [a.id for a in self.actions
                         if a.target == ui_element.id]

            if ui_actions:
                macro = Macro(
                    id=f"macro_{i:04d}",
                    name=f"Macro_{ui_element.category}_{i:04d}",
                    actions=ui_actions[:10],  # 매크로당 최대 10개 액션
                    visible=True,
                    enabled=True
                )
                self.macros.append(macro)

        self.logger.info(f"매크로 생성 완료: {len(self.macros)}개")
        return self.macros

    def embed_json_data(self) -> str:
        """JSON 데이터를 XML에 포함시킬 문자열로 변환"""
        json_data = {
            "project": "HDGRACE",
            "version": "29.2.0",
            "statistics": {
                "ui_elements": len(self.ui_elements),
                "actions": len(self.actions),
                "macros": len(self.macros)
            },
            "features": list(Config.FEATURE_CATEGORIES.keys())
        }
        return json.dumps(json_data, ensure_ascii=False, indent=2)

    def embed_html_template(self) -> str:
        """HTML 템플릿을 XML에 포함"""
        html_template = """<!DOCTYPE html>
<html>
<head>
    <title>HDGRACE BAS Dashboard</title>
    <style>
        body { font-family: Arial, sans-serif; }
        .dashboard { padding: 20px; }
        .stat { display: inline-block; margin: 10px; padding: 10px; border: 1px solid #ccc; }
    </style>
</head>
<body>
    <div class="dashboard">
        <h1>HDGRACE BAS 29.2.0</h1>
        <div class="stat">UI Elements: {ui_count}</div>
        <div class="stat">Actions: {action_count}</div>
        <div class="stat">Macros: {macro_count}</div>
    </div>
</body>
</html>"""
        return html_template.format(
            ui_count=len(self.ui_elements),
            action_count=len(self.actions),
            macro_count=len(self.macros)
        )

    def generate_bas_xml(self) -> ET.Element:
        """BAS XML 생성 - 메인 함수"""
        self.logger.info("BAS XML 생성 시작")

        # 루트 요소
        root = ET.Element("BrowserAutomationStudioProject")
        root.set("version", "29.2.0")

        # Script 섹션
        script_elem = ET.SubElement(root, "Script")
        script_content = self.generate_script_content()
        script_elem.text = self.safe_cdata_wrap(script_content)

        # ModuleInfo - JSON 데이터 포함
        module_info = ET.SubElement(root, "ModuleInfo")
        module_info.text = self.safe_cdata_wrap(self.embed_json_data())

        # Modules
        modules_elem = ET.SubElement(root, "Modules")

        # EmbeddedData - HTML 템플릿 포함
        embedded_data = ET.SubElement(root, "EmbeddedData")
        embedded_data.text = self.safe_cdata_wrap(self.embed_html_template())

        # 필수 요소들
        ET.SubElement(root, "DatabaseId").text = "Database.5066"
        ET.SubElement(root, "Schema")
        ET.SubElement(root, "ConnectionIsRemote").text = "false"
        ET.SubElement(root, "ConnectionServer")
        ET.SubElement(root, "ConnectionPort")
        ET.SubElement(root, "ConnectionLogin")
        ET.SubElement(root, "ConnectionPassword")
        ET.SubElement(root, "HideDatabase").text = "true"
        ET.SubElement(root, "DatabaseAdvanced").text = "true"
        ET.SubElement(root, "DatabaseAdvancedDisabled").text = "true"
        ET.SubElement(root, "ScriptName").text = "HDGRACE_BAS"
        ET.SubElement(root, "ProtectionStrength").text = "4"
        ET.SubElement(root, "UnusedModules").text = "URL;Path;InMail;JSON;ThreadSync"

        # ScriptIcon - Base64 인코딩된 로고
        script_icon = ET.SubElement(root, "ScriptIcon")
        script_icon.text = self.encode_logo_base64()

        # 설정 요소들
        ET.SubElement(root, "IsCustomIcon").text = "false"
        ET.SubElement(root, "HideBrowsers").text = "false"
        ET.SubElement(root, "URLWithServerConfig")
        ET.SubElement(root, "ShowAdvanced").text = "false"
        ET.SubElement(root, "IntegrateScheduler").text = "false"
        ET.SubElement(root, "SingleInstance").text = "false"
        ET.SubElement(root, "CopySilent").text = "false"
        ET.SubElement(root, "IsEnginesInAppData").text = "false"
        ET.SubElement(root, "CompileType").text = "NoProtection"
        ET.SubElement(root, "ScriptVersion").text = "1.0.0"
        ET.SubElement(root, "AvailableLanguages").text = "en"
        ET.SubElement(root, "EngineVersion").text = "29.2.0"

        # ChromeCommandLine - 중복 제거됨
        chrome_cmd = ET.SubElement(root, "ChromeCommandLine")
        chrome_cmd.text = "--disk-cache-size=5000000 --disable-features=OptimizationGuideModelDownloading,AutoDeElevate --lang=en --disable-auto-reload"

        # ModulesMetaJson
        modules_meta = ET.SubElement(root, "ModulesMetaJson")
        modules_meta.text = '{"Archive": false, "FTP": false, "Excel": false, "SQL": false}'

        # Output 타이틀 설정
        for i in range(1, 10):
            title = ET.SubElement(root, f"OutputTitle{i}")
            title.set("en", f"Result {i}")
            title.set("ru", f"Result {i}")

            visible = ET.SubElement(root, f"OutputVisible{i}")
            visible.text = "1" if i <= 3 else "0"

        # ModelList
        ET.SubElement(root, "ModelList")

        # UI Elements 섹션
        ui_container = ET.SubElement(root, "UIElements")
        for ui_elem in self.ui_elements:
            ui_container.append(ui_elem.to_xml_element())

        # Actions 섹션
        actions_container = ET.SubElement(root, "Actions")
        for action in self.actions:
            actions_container.append(action.to_xml_element())

        # Macros 섹션
        macros_container = ET.SubElement(root, "Macros")
        for macro in self.macros:
            macros_container.append(macro.to_xml_element())

        # 필수 26개 블록 추가
        self.add_required_blocks(root)

        self.logger.info("BAS XML 생성 완료")
        return root

    def generate_script_content(self) -> str:
        """스크립트 콘텐츠 생성"""
        return f"""section(1,1,1,0,function(){{
    section_start("HDGRACE Initialize", 0)!

    var hdgrace = {{
        ui_count: {len(self.ui_elements)},
        action_count: {len(self.actions)},
        macro_count: {len(self.macros)},

        init: function() {{
            this.enforceVisible();
            this.loadComponents();
            return true;
        }},

        enforceVisible: function() {{
            var elements = document.querySelectorAll('*');
            for(var i = 0; i < elements.length; i++) {{
                elements[i].setAttribute('visible', 'true');
                elements[i].setAttribute('data-visible', 'true');
                elements[i].setAttribute('aria-visible', 'true');
            }}
        }},

        loadComponents: function() {{
            console.log('Loading ' + this.ui_count + ' UI elements');
            console.log('Loading ' + this.action_count + ' actions');
            console.log('Loading ' + this.macro_count + ' macros');
        }}
    }};

    hdgrace.init();
    section_end()!
}})!"""

    def add_required_blocks(self, root: ET.Element):
        """필수 26개 블록 추가"""
        blocks_container = ET.SubElement(root, "RequiredBlocks")

        for block_name in Config.REQUIRED_BLOCKS:
            block = ET.SubElement(blocks_container, block_name)
            block.set("enabled", "true")
            block.set("version", "29.2.0")

            # 블록별 특수 속성
            if block_name == "Security":
                block.set("type", "AES256")
            elif block_name == "Network":
                block.set("proxy_count", "5000")
            elif block_name == "ThreadMonitor":
                block.set("max_threads", "3000")

    def save_xml(self, root: ET.Element, filename: str):
        """XML 파일 저장"""
        try:
            # Pretty print를 위한 문자열 변환
            xml_str = ET.tostring(root, encoding='unicode')
            dom = minidom.parseString(xml_str)
            pretty_xml = dom.toprettyxml(indent="    ")

            # 빈 줄 제거
            lines = [line for line in pretty_xml.split('\n') if line.strip()]
            pretty_xml = '\n'.join(lines)

            # 파일 저장
            filepath = os.path.join(Config.OUTPUT_DIR, filename)
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write(pretty_xml)

            self.logger.info(f"XML 파일 저장 완료: {filepath}")

            # 통계 파일 생성
            self.save_statistics(filename)

        except Exception as e:
            self.logger.error(f"XML 저장 실패: {e}")
            raise

    def save_statistics(self, xml_filename: str):
        """통계 파일 저장"""
        stats = {
            "generated": datetime.now().isoformat(),
            "xml_file": xml_filename,
            "statistics": {
                "ui_elements": len(self.ui_elements),
                "actions": len(self.actions),
                "macros": len(self.macros),
                "categories": dict(Config.FEATURE_CATEGORIES)
            },
            "validation": {
                "bas_version": "29.2.0",
                "required_blocks": len(Config.REQUIRED_BLOCKS),
                "visible_triple_check": True,
                "json_embedded": True,
                "html_embedded": True,
                "logo_base64": True
            }
        }

        stats_file = os.path.join(Config.OUTPUT_DIR, "_STATISTICS.json")
        with open(stats_file, 'w', encoding='utf-8') as f:
            json.dump(stats, f, ensure_ascii=False, indent=2)

        self.logger.info(f"통계 파일 저장: {stats_file}")

        # 검증 보고서
        validation_file = os.path.join(Config.OUTPUT_DIR, "_VALIDATION.txt")
        with open(validation_file, 'w', encoding='utf-8') as f:
            f.write("HDGRACE BAS XML Validation Report\n")
            f.write("=" * 50 + "\n")
            f.write(f"Generated: {datetime.now()}\n")
            f.write(f"File: {xml_filename}\n")
            f.write(f"Status: SUCCESS\n")
            f.write(f"UI Elements: {len(self.ui_elements)}\n")
            f.write(f"Actions: {len(self.actions)}\n")
            f.write(f"Macros: {len(self.macros)}\n")
            f.write(f"BAS Version: 29.2.0\n")
            f.write(f"JSON Embedded: Yes\n")
            f.write(f"HTML Embedded: Yes\n")
            f.write(f"Logo Base64: Yes\n")

        self.logger.info(f"검증 보고서 저장: {validation_file}")

# ====================== 메인 실행 ======================
def main():
    """메인 실행 함수"""
    print("=" * 60)
    print("HDGRACE BAS XML Generator - Fixed Version")
    print("BAS 29.2.0 Compatible")
    print("=" * 60)

    start_time = time.time()

    try:
        # 생성기 인스턴스
        generator = BASXMLGenerator()

        # 컴포넌트 생성
        print("\n1. UI 요소 생성 중...")
        generator.generate_ui_elements()

        print("2. 액션 생성 중...")
        generator.generate_actions()

        print("3. 매크로 생성 중...")
        generator.generate_macros()

        print("4. BAS XML 생성 중...")
        root = generator.generate_bas_xml()

        # 파일 저장
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = f"HDGRACE_BAS_Final_{timestamp}.xml"

        print(f"5. XML 파일 저장 중: {filename}")
        generator.save_xml(root, filename)

        elapsed = time.time() - start_time

        # 결과 출력
        print("\n" + "=" * 60)
        print("✅ 생성 완료!")
        print(f"📁 파일 위치: {Config.OUTPUT_DIR}")
        print(f"📄 파일명: {filename}")
        print(f"⏱️ 소요 시간: {elapsed:.2f}초")
        print(f"📊 UI 요소: {len(generator.ui_elements):,}개")
        print(f"⚡ 액션: {len(generator.actions):,}개")
        print(f"🔄 매크로: {len(generator.macros):,}개")
        print("=" * 60)

        return True

    except Exception as e:
        logger.error(f"생성 중 오류 발생: {e}", exc_info=True)
        print(f"\n❌ 오류 발생: {e}")
        return False

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)